<template>
  <div v-if="id === 10079" class="dashboard-container">
    <el-tabs v-model="activeName">
      <el-tab-pane label="创建用户" name="first">
        <PageOne />
      </el-tab-pane>
      <el-tab-pane label="用户更新/删除" name="second">
        <PageTwo />
      </el-tab-pane>
      <el-tab-pane label="角色创建" name="third">
        <PageThree />
      </el-tab-pane>
      <el-tab-pane label="角色更新/删除" name="fourth">
        <PageFour />
      </el-tab-pane>
      <el-tab-pane label="租户管理" name="fifth">
        <PageFive />
      </el-tab-pane>
    </el-tabs>
  </div>
  <div v-else class="second">
    <div>抱歉！您无权查看本页面</div>
  </div>
</template>

<script>
import PageOne from './pages/PageOne.vue'
import PageTwo from './pages/PageTwo.vue'
import PageThree from './pages/PageThree.vue'
import PageFour from './pages/PageFour.vue'
import PageFive from './pages/PageFive.vue'
export default {
  name: 'Dashboard',
  components: { PageOne, PageTwo, PageThree, PageFour, PageFive },
  data() {
    return {
      activeName: 'first',
      id: this.$store.state.user.id
    }
  },
  computed: {
  },
  created() {
    this.setData()
  },
  methods: {
    async setData() {
      await this.$store.dispatch('user/getPermissions')
      await this.$store.dispatch('user/getRoles')
      await this.$store.dispatch('user/getNums')
    },
  }
}
</script>

<style lang="scss" scoped>
.dashboard {
  &-container {
    margin: 30px;
  }
  &-text {
    font-size: 30px;
    line-height: 46px;
  }
}
.second {
  width: 50vw;
  height: 50vh;
  margin: 18vh auto;
  background-color: #283443;
  display: flex;
  justify-content: center;
  align-items: center;
  border-radius: 10px;
  div {
    font-size: 30px;
    color: white;
  }
}
</style>
