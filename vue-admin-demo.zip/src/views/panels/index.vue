<template>
  <div class="dashboard-container">
    <!-- <div class="dashboard-text">name: {{ name }}</div> -->
    <el-tabs v-model="activeName">
      <el-tab-pane label="用户列" name="first">
        <PageOne />
      </el-tab-pane>
      <el-tab-pane label="租户列" name="second">
        <PageTwo />
      </el-tab-pane>
    </el-tabs>
  </div>
</template>

<script>
import PageOne from './pages/PageOne.vue'
import PageTwo from './pages/PageTwo.vue'
export default {
  name: 'Dashboard',
  components: { PageOne, PageTwo },
  data() {
    return {
      activeName: 'first'
    }
  },
  created() {
    this.setData()
  },
  methods: {
    async setData() {
      await this.$store.dispatch('user/getPermissions')
      await this.$store.dispatch('user/getRoles')
      await this.$store.dispatch('user/getNums')
    },
  }
}
</script>

<style lang="scss" scoped>
.dashboard {
  &-container {
    margin: 30px;
  }
  &-text {
    font-size: 30px;
    line-height: 46px;
  }
}
</style>
