<template>
  <div class="container">
    <el-table
      :data="users"
      style="width: 100%"
      :row-class-name="tableRowClassName"
    >
      <el-table-column
        prop="id"
        label="ID"
      />
      <el-table-column
        prop="userName"
        label="用户ID"
        width="180"
      />
      <el-table-column
        prop="name"
        label="用户名"
      />
      <el-table-column
        prop="emailAddress"
        label="邮箱"
      />
    </el-table>
  </div>
</template>

<script>
export default {
  data() {
    return {
      users: this.$store.state.user.users
    }
  },
  created() {
  },
  mounted() {
  },
  methods: {
    tableRowClassName({ row, rowIndex }) {
      if (rowIndex === 1) {
        return 'warning-row'
      } else if (rowIndex === 3) {
        return 'success-row'
      }
      return ''
    }
  }
}
</script>

<style lang="scss" scoped>
.container{
  .el-table .warning-row {
    background: oldlace;
  }
  .el-table .success-row {
    background: #f0f9eb;
  }
}
</style>
