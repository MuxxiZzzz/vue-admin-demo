<template>
  <div style="height: 100%">
    <el-table
      :data="tenants"
      style="width: 100%"
      :row-class-name="tableRowClassName"
    >
      <el-table-column
        prop="id"
        label="ID"
      />
      <el-table-column
        prop="tenancyName"
        label="用户ID"
        width="180"
      />
      <el-table-column
        prop="name"
        label="租户显示名称"
      />
    </el-table>
  </div>
</template>

<script>
export default {
  data() {
    return {
      tenants: this.$store.state.user.tenants,
    }
  },
  created() {
  },
  mounted() {
  },
  methods: {
    tableRowClassName({ row, rowIndex }) {
      if (rowIndex === 1) {
        return 'warning-row'
      } else if (rowIndex === 3) {
        return 'success-row'
      }
      return ''
    }
  }
}
</script>

<style lang="scss" scoped>
.container{
  .el-table .warning-row {
    background: oldlace;
  }
  .el-table .success-row {
    background: #f0f9eb;
  }
}
</style>
