import request from '@/utils/request'

export function login(data) {
  return request({
    url: '/api/TokenAuth/Authenticate',
    method: 'post',
    data
  })
}
export function regist(data) {
  return request({
    url: '/api/services/app/Account/Register',
    method: 'post',
    data
  })
}

export function getInfo(id) {
  return request({
    url: '/api/services/app/User/Get',
    method: 'get',
    params: { id }
  })
}

export function getRoles() {
  return request({
    url: '/api/services/app/Role/GetRoles',
    method: 'get',
  })
}

export function getNums() {
  return request({
    url: '/api/services/app/User/GetAll',
    method: 'get',
  })
}

export function getPermissions() {
  return request({
    url: '/api/services/app/Role/GetAllPermissions',
    method: 'get',
  })
}

export function getTenants() {
  return request({
    url: '/api/services/app/Tenant/GetAll',
    method: 'get',
  })
}

export function logout() {
  return request({
    url: '/vue-admin-template/user/logout',
    method: 'post'
  })
}

export function deleteTenant(id) {
  return request({
    url: '/api/services/app/Tenant/Delete?Id=' + id,
    method: 'delete',
  })
}
