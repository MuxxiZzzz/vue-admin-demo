import { login, logout, getInfo, regist, getRoles, getNums, getPermissions, getTenants, deleteTenant } from '@/api/user'
import { getToken, setToken, removeToken } from '@/utils/auth'
import { resetRouter } from '@/router'
import { Message } from 'element-ui'
const Mock = require('mockjs')
// Mock.mock(/http:\/\/localhost:21021\/vue-admin-template\/user\/info.*/, () => {
//   return {
//     code: 20000,
//     data: {
//       roles: ['admin'],
//       introduction: 'I am a super administrator',
//       avatar: 'https://wpimg.wallstcn.com/f778738c-e4f8-4870-b634-56703b4acafe.gif',
//       name: 'Super Admin'
//     }
//   }
// })
Mock.mock('http://localhost:21021/vue-admin-template/user/logout', () => {
  return {
    code: 20000,
    data: 'success'
  }
})
const getDefaultState = () => {
  return {
    token: getToken(),
    name: '',
    avatar: '',
    id: '',
  }
}

const state = getDefaultState()

const mutations = {
  RESET_STATE: (state) => {
    Object.assign(state, getDefaultState())
  },
  SET_TOKEN: (state, token) => {
    state.token = token
  },
  SET_ID: (state, id) => {
    state.id = id
  },
  SET_NAME: (state, name) => {
    state.name = name
  },
  SET_AVATAR: (state, avatar) => {
    state.avatar = avatar
  }
}

const actions = {
  // user login
  login({ commit }, userInfo) {
    const { complex, password } = userInfo
    // console.log({ complex, password })
    return new Promise((resolve, reject) => {
      login({ userNameOrEmailAddress: complex.trim(), password: password }).then(response => {
        const { data } = response
        commit('SET_TOKEN', data.result.accessToken)
        commit('SET_ID', data.result.userId)
        setToken(data.result.accessToken)
        // console.log(data.accessToken)
        resolve()
      }).catch(error => {
        const mesgNull = {
          message: error.response.data.error.message,
          type: 'error',
          dangerouslyUseHTMLString: true,
        }
        const mesg = {
          message: error.response.data.error.message + '<br/><br/>' + error.response.data.error.details,
          type: 'error',
          dangerouslyUseHTMLString: true,
        }
        if (error.response.data.error.details == null) {
          // console.log(mesgNull)
          Message(mesgNull)
        } else {
          // console.log(mesg)
          Message(mesg)
        }
        reject(error)
      })
    })
  },
  regist({ commit }, userInfo) {
    const { username, userid, useremail, password } = userInfo
    return new Promise((resolve, reject) => {
      regist({ name: username, surname: username, userName: userid, emailAddress: useremail, password: password }).then(response => {
        const { data } = response
        if (data.success) { Message('注册成功') }
        resolve()
      }).catch(error => {
        const mesgNull = {
          message: error.response.data.error.message,
          type: 'error',
          dangerouslyUseHTMLString: true,
        }
        const mesg = {
          message: error.response.data.error.message + '<br/><br/>' + error.response.data.error.details,
          type: 'error',
          dangerouslyUseHTMLString: true,
        }
        if (error.response.data.error.details == null) {
          Message(mesgNull)
        } else {
          Message(mesg)
        }
        reject(error)
      })
    })
  },
  // get user info
  getInfo({ commit, state }) {
    // console.log(state.token)  有token
    return new Promise((resolve, reject) => {
      getInfo(state.id).then(response => {
        const { data } = response

        if (!data) {
          return reject('Verification failed, please Login again.')
        }
        const name = data.result.name
        const avatar = 'https://wpimg.wallstcn.com/f778738c-e4f8-4870-b634-56703b4acafe.gif'
        // const { name, avatar } = data.result

        commit('SET_NAME', name)
        commit('SET_AVATAR', avatar)
        resolve(data)
      }).catch(error => {
        console.log('getINFO进入错误')
        reject(error)
      })
    })
  },
  // get roles
  getRoles({ commit, state }) {
    // console.log(state.token)  有token
    return new Promise((resolve, reject) => {
      getRoles(state.id).then(response => {
        const data = response.data.result.items
        // console.log(data)
        // if (!data) {
        //   return reject('获取失败，请联系管理员')
        // }
        // console.log(data)
        resolve(data)
      }).catch(error => {
        console.log('getRoles进入错误')
        console.log(error)
        reject(error)
      })
    })
  },

  getNums({ commit, state }) {
    // console.log(state.token)  有token
    return new Promise((resolve, reject) => {
      getNums(state.id).then(response => {
        const data = response.data.result.items
        // console.log(data)
        // if (!data) {
        //   return reject('获取失败，请联系管理员')
        // }
        // console.log(data)
        resolve(data)
      }).catch(error => {
        console.log('getNums进入错误')
        console.log(error)
        reject(error)
      })
    })
  },

  getPermissions({ commit, state }) {
    // console.log(state.token)  有token
    return new Promise((resolve, reject) => {
      getPermissions(state.id).then(response => {
        const data = response.data.result.items
        // console.log(data)
        // if (!data) {
        //   return reject('获取失败，请联系管理员')
        // }
        // console.log(data)
        resolve(data)
      }).catch(error => {
        console.log('getNums进入错误')
        console.log(error)
        reject(error)
      })
    })
  },

  getTenants({ commit, state }) {
    // console.log(state.token)  有token
    return new Promise((resolve, reject) => {
      getTenants(state.id).then(response => {
        const data = response.data.result.items
        resolve(data)
      }).catch(error => {
        console.log('getNums进入错误')
        console.log(error)
        reject(error)
      })
    })
  },

  deleteTenant({ commit, state }, id) {
    return new Promise((resolve, reject) => {
      deleteTenant(id).then(response => {
        const data = response.data.result.items
        resolve(data)
      }).catch(error => {
        reject(error)
      })
    })
  },

  // user logout
  logout({ commit, state }) {
    return new Promise((resolve, reject) => {
      logout(state.token).then(() => {
        removeToken() // must remove  token  first
        resetRouter()
        commit('RESET_STATE')
        resolve()
      }).catch(error => {
        reject(error)
      })
    })
  },

  // remove token axios拦截器
  resetToken({ commit }) {
    return new Promise(resolve => {
      removeToken() // must remove  token  first
      commit('RESET_STATE')
      resolve()
    })
  }
}

export default {
  namespaced: true,
  state,
  mutations,
  actions
}

