<template>
  <div class="container">
    <div v-if="status">
      <el-form ref="form" :model="form" label-width="80px">
        <el-form-item label="租户名" prop="username" :rules="rules.tenantName">
          <el-input v-model="form.tenantName" />
        </el-form-item>
        <el-form-item label="启用租户">
          <el-switch v-model="form.activation" />
        </el-form-item>
        <el-form-item>
          <div style="display: flex;justify-content: space-between;">
            <el-button type="primary" style="width: 70%" @click.native="onSubmit">创建租户</el-button>
            <el-button type="primary" style="width: 30%" @click.native="switcher">
              <span class="el-icon-right" />
            </el-button>
          </div>
        </el-form-item>
      </el-form>
    </div>
    <div v-if="!status">
      <el-form ref="form2" :model="form" label-width="auto">
        <el-form-item label="选择租户">
          <el-select v-model="form.tenantId" placeholder="选择租户" style="width:80%">
            <el-option v-for="(tenant, index) in form.tenants" :key="index" :label="tenant.tenancyName" :value="tenant.id" />
          </el-select>
        </el-form-item>
        <el-form-item>
          <div>
            <el-button type="primary" size="medium" style="width: 50%" @click.native="accountDelete(form.tenantId)">删除账户</el-button>
            <el-button type="primary" size="medium" style="width: 28.5%" @click.native="switcher">
              <span class="el-icon-right" />
            </el-button>
          </div>
        </el-form-item>
      </el-form>
    </div>
  </div>
</template>

<script>
import { validateUsername } from '@/utils/validate'
export default {
  data() {
    return {
      status: true,
      form: {
        tenantName: '',
        tenants: '',
        tenantId: '',
        activation: true,
      },
      rules: {
        tenantName: [{ required: true, trigger: 'blur', validator: validateUsername }],
      },
    }
  },
  created() {
    this.getTenants()
  },
  mounted() {

  },
  methods: {
    onSubmit() {
      console.log('submit!')
    },
    getTenants() {
      this.$store.dispatch('user/getTenants').then((data) => {
        this.form.tenants = data
      }).catch(() => {
        this.form.tenants = [{
          tenancyName: '获取错误',
          name: ''
        }]
      })
    },
    accountDelete(id) {
      if (id === '') {
        this.$message('请选择要操作的租户')
      } else {
        this.$store.dispatch('user/deleteTenant', id).then((data) => {
          this.form.tenants = data
        }).catch(() => {
        // console.log(error)
          this.$message({
            message: '没有权限操作',
            type: 'error'
          })
        })
      }
    },
    switcher() {
      this.status = !this.status
    },
  }
}
</script>

<style lang="scss" scoped>
.container {
    width: 50%;
    margin: 5% auto;
}
</style>
